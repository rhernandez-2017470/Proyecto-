'use strict' 
const categoryController = require('../controllers/category.controller'); 
const express = require('express');
const api = express.Router(); 
const mdAuth = require('../services/authenticated'); 

api.get('/testCategory', categoryController.testCategory); 
api.post('/saveCategory', [mdAuth.ensureAuth, mdAuth.isAdmin], categoryController.saveCategory);   
api.get('/getCategories', categoryController.getCategories);  
api.put('/updateCategory/:id', [mdAuth.ensureAuth, mdAuth.isAdmin], categoryController.upddateCategory);  
api.get('/mensaje/:id', categoryController.mensaje);  
api.delete('/deleteCategory/:id', [mdAuth.ensureAuth, mdAuth.isAdmin], categoryController.deleteCategory); 
api.get('/getCatalogo/:id', categoryController.getCatalogo);   

module.exports = api;