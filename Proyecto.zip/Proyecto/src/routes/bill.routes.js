'use strict' 
const billController = require('../controllers/bill.controller');
const express = require('express');
const api = express.Router();
const mdAuth = require('../services/authenticated'); 

api.post('/generateBill', mdAuth.ensureAuth, billController.generateBill); 
api.post('/searchBills/:id', mdAuth.ensureAuth, billController.searchBills); 
api.post('/showProducts/:id', mdAuth.ensureAuth, billController.showProducts);


module.exports = api; 