'use strict' 
const userController = require('../controllers/user.controller');  
const express = require('express'); 
const api = express.Router();  
const mdAuth = require('../services/authenticated'); 

api.get('/test', [mdAuth.ensureAuth, mdAuth.isAdmin] ,userController.test);  
api.post('/register', userController.register); 
api.post('/login', userController.login); 
api.put('/update/:id', mdAuth.ensureAuth, mdAuth.isAdmin, userController.update); 
api.delete('/delete/:id', mdAuth.ensureAuth, userController.delete); 
api.put('/updateRole/:id', mdAuth.ensureAuth, userController.updateRole);  
api.put('/updateClient/:id', [mdAuth.ensureAuth, mdAuth.isClient], userController.updateClient);

module.exports = api;