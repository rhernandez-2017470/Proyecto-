'use strict'  
const shoppingCartController = require('../controllers/shoppingCart.controller'); 
const express = require('express');
const api = express.Router(); 
const mdAuth = require('../services/authenticated'); 

api.get('/testShopping', shoppingCartController.testShopping);    
api.post('/saveCart', mdAuth.ensureAuth, shoppingCartController.saveCart); 

module.exports = api; 