'use strict' 

const {validateData, checkUpdate} = require('../utils/validate');  
const Product = require('../models/product.model');  
const User = require('../models/user.model'); 
const ShoppingCart = require('../models/shoppingCart.model'); 
const Bill = require('../models/bill.model'); 

exports.test= async (req, res)=>{ 
    res.send({message: 'Test Bill'})
}
exports.generateBill = async (req, res) => {
    try {
     const userId = req.user.sub;
     const findCart = await ShoppingCart.findOne({ user: userId }).populate('products.product').lean();
     if (findCart === null) return res.send({ message: 'you have not added any product'});
else 
    for (let index = 0; index < findCart.products.length; index++) {
        const shoppingCartProduct = await findCart.products[index];
        const getProduct = await findCart.products[index].product.valueOf();
        const product = await Product.findOne({ _id: getProduct }).lean();
        let quantity = shoppingCartProduct.quantity;
            const data = { 
                stock: product.stock, 
                sales: product.sales 
            }
        data.stock = (product.stock - quantity);
        data.sales = (product.sales + quantity)
        await Product.findOneAndUpdate({ _id: getProduct }, data, { new: true }).lean()
    }
        const bill = new Bill(findCart);
        await bill.save();
        await ShoppingCart.findOneAndRemove({ user: userId });
        return res.send({ message: 'This is your bill, Thanks for shopping with us', bill});
    } catch (error) {
        console.log(error);
        return error;
    }
} 
exports.showProducts = async (req, res) => {
    try {
        const userId = req.params.id;
        let searchProducts = await Bill.find({ user: userId }).populate('products.product').lean();
        if (searchProducts.length === 0) return res.send({ message: 'there is not any bill to show'});
         else return res.send({searchProducts});
    } catch (error) {
        console.log(error);
        return error;
    }
}
exports.searchBills = async (req, res) => {
    try {
        const userId = req.params.id;
        let searchBill = await Bill.find({ user: userId }).lean();
        if (searchBill.length === 0) return res.send({ message: 'there is not any bill to show'});
         else return res.send({ searchBill });
    } catch (error) {
        console.log(error);
        return error;
    }
}