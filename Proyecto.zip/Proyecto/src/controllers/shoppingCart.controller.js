'use strict'
const User = require('../models/user.model')
const { validateData, checkUpdate, searchCart } = require('../utils/validate');
const Product = require('../models/product.model');
const ShoppingCart = require('../models/shoppingCart.model')
const mongoose = require('mongoose');

exports.testShopping = (req, res) => {
    res.send({ message: 'test shpoing is running' })
}
exports.saveCart = async (req, res) => {
    try {
        const params = req.body;
        const userId = req.user.sub;
        let data = {
            product: params.product,
            quantity: params.quantity
        }
        let msg = validateData(data);
        if (!msg) {
        const searchProduct = await Product.findOne({ _id: data.product });
         if (data.quantity >= searchProduct.stock) return res.send({ message: 'we do not have that quantity of products' });
        else {
          let checkShoppingCart = await searchCart(userId);
        if (!checkShoppingCart) {
            data.user = userId;
            data.subtotal = (searchProduct.price * data.quantity);
            data.total = (data.subtotal);
            let shoppingCart = new ShoppingCart(data)
            await shoppingCart.save();
            let shoppingCartId = await ShoppingCart.findOne({ user: userId })
            let pushCart = await ShoppingCart.findOneAndUpdate({ _id: shoppingCartId._id }, { $push: { products: data } }, { new: true })
            .populate('products.product').lean();
            return res.send({ message: 'Product added succesfully', pushCart })
        } else {
            let CartId = await ShoppingCart.findOne({ user: userId })
            data.subtotal = (searchProduct.price * data.quantity);
            data.total = (data.subtotal + CartId.total); 
            let pushCart = await ShoppingCart.findOneAndUpdate({ _id: CartId._id }, { $push: { products: data }, total: data.total }, { new: true })
            .populate('products.product').lean();
            return res.send({ message: 'Product added succesfully', pushCart }) 
                }
            }
        } else return res.status(400).send(msg);
    } catch (error) {
        console.log(error);
        return error;
    }
}