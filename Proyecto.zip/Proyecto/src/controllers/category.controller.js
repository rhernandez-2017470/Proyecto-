'use strict' 
const Category = require('../models/category.model'); 
const { validateData, checkUpdate, defultCategory } = require('../utils/validate'); 
const Product = require('../models/product.model');

exports.testCategory = (req, res)=>{ 
    return res.send({message: 'function testCategory is running'});  
    

}  
exports.saveCategory = async(req, res)=>{ 
    try { 
        const params = req.body;
        const data = { 
            name: params.name
        } 

        const msg = validateData(data); 
        if (!msg) {
            data.description = params.description 
            const category = new Category(data); 
            await category.save(); 
            return res.send({message: 'Category saved'});
        } else {
            return res.status(400).send(msg);
        }
    } catch (error) {
        console.log(error); 
        return error;
    }
} 
exports.getCategories = async (req, res)=>{ 
    try {
        const categories = await Category.find(); 
        return res.send(categories);
    } catch (error) {
        console.log(error); 
        return error;
    }
} 
exports.upddateCategory = async (req, res)=>{ 
    try {
        const params = req.body; 
        const categoryId = req.params.id; 
        const checkDefault = await defultCategory(categoryId);
        if (checkDefault === true) {
            return res.send({message: 'no puedes modificar o eliminar esta categoria'});
        } else {
            const check = await checkUpdate(params); 
            if(check === false) return res.status(400).send({message: 'Data not received'}); 
            const updateCategory = await Category.findOneAndUpdate({_id: categoryId}, params, {new: true}) 
            if(!updateCategory) return res.send({message: 'category not found'}); 
            return res.send({message: 'category updated', updateCategory});
        } 
        
    } catch (error) {
        console.log(error); 
        return error;
    }
}  
exports.mensaje = async (req, res)=>{ 
    try {
        const categoryId = req.params.id 
        const check = await defultCategory(categoryId);
        if (check === true) {
            return res.send({message: 'no puedes modificar o eliminar esta categoria'});
        } else {
            return res.send({message: 'estás modificando otra categoria que no es default'});
        }
    } catch (error) {
        console.log(error); 
        return error;
    }
} 
exports.deleteCategory = async (req, res) => {
    try {
        const categoryId = req.params.id;
        const findDefault = await Category.findOne({ category: 'Default' })
        if (findDefault.id === categoryId) {
            return res.send({ message: 'this category dont can not be delited' })
        } else {
            const deleteCategory = await Category.findOneAndDelete({ _id: categoryId });
            if (!deleteCategory) {
                return res.status(404).send({ message: 'category not foun or already deleted' })
            } else {
                const updateProduct = await Product.updateMany({ category: categoryId }, { category: findDefault.id }, { new: true })
                return res.send({ message: 'category deleted succesfully, now the product is part of Default', updateProduct })
            }
        }
    } catch (err) {
        console.log(err);
        return err;
    }
} 
exports.getCatalogo = async (req, res) =>{ 
    try {
        const categoryId = req.params.id;  
        const showCategory = await Category.findOne({_id: categoryId}); 
        if (!showCategory) {
            return res.status(404).send({ message: 'category not foun or already deleted' })
        } else { 
            const showProduct = await Product.find({category: categoryId}); 
            return res.send({message: 'Estos es la categoria y sus productos: ', showCategory, showProduct});
        
        
     
        } 
        

    } catch (error) {
        console.log(error); 
        return error;
    }
}